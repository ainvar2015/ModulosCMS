<?php

namespace App\Modules\News\Models;

use CodeIgniter\Model;

class ArticleTranslationModel extends Model
{
    protected $table         = 'news_translations';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['article_id', 'lang', 'title', 'summary', 'content'];
    protected $useTimestamps = true;
}