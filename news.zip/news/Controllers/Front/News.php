<?php

namespace App\Modules\News\Controllers\Front;

use App\Controllers\BaseController;
use App\Modules\News\Models\NewsModel;
use App\Modules\News\Models\NewsCategoryModel;

class News extends BaseController
{
    protected $helpers = ['url', 'html', 'menu', 'i18n', 'thumb'];

    /** Modo parcial: true cuando se renderiza dentro de la página-módulo */
    public $embed = false;

    private function getThemePath(): string
    {
        $themeModel = new \App\Models\ThemeModel();
        $active = $themeModel->where('active', 1)->first();
        return $active['slug'] ?? 'default';
    }

    private function getLanguages(): array
    {
        try {
            $langModel = new \App\Modules\I18n\Models\LanguageModel();
            return $langModel->where('active', 1)->orderBy('sort_order', 'ASC')->findAll();
        } catch (\Exception $e) {
            return [];
        }
    }

    private function getLangData(): array
    {
        $configModel = new \App\Models\ConfigModel();
        $defaultLang = $configModel->get('site_language', 'es');
        $currentLang = \current_lang() ?: $defaultLang;
        return [
            'current_lang' => $currentLang,
            'default_lang' => $defaultLang,
            'languages'    => $this->getLanguages(),
        ];
    }

    /** Slug de la página-módulo en el idioma actual */
    private function getPageBase(): string
    {
        $page = (new \App\Models\PageModel())
            ->where('type', 'module')->where('module_name', 'news')->where('status', 'published')->first();
        if (!$page) return 'noticias';

        $lang = \current_lang();
        if ($lang !== default_lang()) {
            $trans = (new \App\Models\PageTranslationModel())
                ->where('page_id', $page['id'])->where('lang', $lang)->first();
            if ($trans && !empty($trans['slug'])) return $trans['slug'];
        }
        return $page['slug'];
    }

    private function getModulePage(): ?array
    {
        $page = (new \App\Models\PageModel())
            ->where('type', 'module')->where('module_name', 'news')->where('status', 'published')->first();
        return $page ?: null;
    }

    private function getTranslationSlugs(): array
    {
        $page = $this->getModulePage();
        if (!$page) return [];
        $slugs = [default_lang() => $page['slug']];
        foreach ((new \App\Models\PageTranslationModel())->where('page_id', $page['id'])->findAll() as $t) {
            $slugs[$t['lang']] = $t['slug'];
        }
        return $slugs;
    }

    public function index()
    {
        $newsModel = new NewsModel();
        $catModel  = new NewsCategoryModel();
        $request   = service('request');

        $catSlug = $request->getGet('categoria');
        $catId   = null;
        if ($catSlug) {
            $c = $catModel->where('slug', $catSlug)->where('active', 1)->first();
            if ($c) $catId = (int) $c['id'];
        }

        $data = array_merge([
            'articles'   => $newsModel->getPublished($catId),
            'featured'   => $catId ? [] : $newsModel->getFeatured(1),   // destacado solo en vista general
            'categories' => $catModel->getActive(),
            'activeCat'  => $catSlug,
            'pageBase'   => $this->getPageBase(),
        ], $this->getLangData());

        // Modo parcial (incrustado en la página-módulo): solo el grid
        if ($this->embed) {
            return view('App\Modules\News\Views\front\_grid', $data);
        }

        // Standalone: pintamos igual que una página (misma plantilla page.php)
        $themePath = $this->getThemePath();
        $title = lang('News.title');

        return view('front/themes/' . $themePath . '/page', [
            'title'             => $title,
            'meta_desc'         => null,
            'page'              => [
                'title'   => $title,
                'content' => view('App\Modules\News\Views\front\_grid', $data),
                'type'    => 'module',
            ],
            'base_url'          => base_url(),
            'theme_url'         => base_url('themes/' . $themePath),
            'themePath'         => $themePath,
            'template_slug'     => null,
            'template_fields'   => [],
            'template_data'     => [],
            'current_lang'      => $data['current_lang'],
            'default_lang'      => $data['default_lang'],
            'languages'         => $data['languages'],
            'translation_slugs' => $this->getTranslationSlugs(),
        ]);
    }

    public function article($slug)
    {
        $newsModel = new NewsModel();
        $article   = $newsModel->getBySlug($slug);

        // Solo activos y ya publicados (fecha pasada)
        if (!$article || !$article['active'] || strtotime((string) $article['published_at']) > time()) {
            return redirect()->to(localized_url($this->getPageBase()));
        }

        $related = [];
        if (!empty($article['category_id'])) {
            $related = $newsModel->getPublished((int) $article['category_id'], 4);
            $related = array_values(array_filter($related, fn($r) => $r['id'] != $article['id']));
            $related = array_slice($related, 0, 3);
        }

        $themePath = $this->getThemePath();
        $title     = news_field($article, 'title');
        $summary   = news_field($article, 'summary');

        return view('App\Modules\News\Views\front\article', array_merge([
            'title'             => $article['meta_title'] ?: $title,
            'meta_desc'         => $article['meta_desc'] ?: mb_substr(strip_tags($summary), 0, 160),
            'article'           => $article,
            'related'           => $related,
            'pageBase'          => $this->getPageBase(),
            'translation_slugs' => $this->getTranslationSlugs(),
            'base_url'          => base_url(),
            'theme_url'         => base_url('themes/' . $themePath),
            'themePath'         => $themePath,
        ], $this->getLangData()));
    }
}