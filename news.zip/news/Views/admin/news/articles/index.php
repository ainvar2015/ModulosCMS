<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Artículos</h1>
    <a href="<?= base_url('admin/news/articles/create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Nuevo artículo
    </a>
</div>

<form method="get" class="row g-2 mb-3">
    <div class="col-md-4">
        <input type="text" name="q" class="form-control" placeholder="Buscar por título o resumen..."
            value="<?= esc($q) ?>">
    </div>
    <div class="col-md-3">
        <select name="categoria" class="form-select">
            <option value="">Todas las categorías</option>
            <?php foreach ($categories as $c): ?>
                <option value="<?= esc($c['slug']) ?>" <?= $activeCat === $c['slug'] ? 'selected' : '' ?>>
                    <?= esc($c['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-2">
        <button class="btn btn-outline-primary w-100"><i class="bi bi-search"></i> Filtrar</button>
    </div>
</form>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-3">Título</th>
                    <th>Categoría</th>
                    <th>Publicación</th>
                    <th>Destacado</th>
                    <th>Activo</th>
                    <th class="text-end pe-3">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($articles)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">No hay artículos. Crea el primero.</td></tr>
                <?php else: foreach ($articles as $a): ?>
                    <tr>
                        <td class="ps-3">
                            <strong><?= esc($a['title']) ?></strong><br>
                            <small class="text-muted"><code><?= esc($a['slug']) ?></code></small>
                        </td>
                        <td>
                            <?php
                            $cat = null;
                            if ($a['category_id']) {
                                foreach ($categories as $c) if ($c['id'] == $a['category_id']) $cat = $c;
                            }
                            echo $cat ? esc($cat['name']) : '<span class="text-muted">—</span>';
                            ?>
                        </td>
                        <td><?= esc($a['published_at']) ?></td>
                        <td>
                            <a href="<?= base_url('admin/news/articles/toggle-featured/' . $a['id']) ?>"
                               class="btn btn-sm <?= $a['featured'] ? 'btn-warning' : 'btn-outline-warning' ?>">
                                <i class="bi bi-star<?= $a['featured'] ? '-fill' : '' ?>"></i>
                            </a>
                        </td>
                        <td>
                            <a href="<?= base_url('admin/news/articles/toggle/' . $a['id']) ?>"
                               class="btn btn-sm <?= $a['active'] ? 'btn-success' : 'btn-outline-secondary' ?>">
                                <?= $a['active'] ? 'Sí' : 'No' ?>
                            </a>
                        </td>
                        <td class="text-end pe-3">
                            <a href="<?= base_url('admin/news/articles/edit/' . $a['id']) ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="<?= base_url('admin/news/articles/delete/' . $a['id']) ?>" method="post" class="d-inline"
                                onsubmit="return confirm('¿Eliminar este artículo y sus traducciones?')">
                                <?= csrf_field() ?>
                                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $this->endSection() ?>