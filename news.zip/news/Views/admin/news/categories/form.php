<?php $this->extend('admin/layout') ?>
<?php $this->section('content') ?>
<?php $isEdit = !empty($c); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2"><?= esc($title) ?></h1>
    <a href="<?= base_url('admin/news/categories') ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Volver</a>
</div>
<div class="row">
    <div class="col-lg-8">
        <form action="<?= $action ?>" method="post">
            <?= csrf_field() ?>
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nombre <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" required value="<?= old('name', $c['name'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Slug</label>
                        <input type="text" name="slug" class="form-control" value="<?= old('slug', $c['slug'] ?? '') ?>">
                        <div class="form-text">Vacío = se genera del nombre.</div>
                    </div>
                    <?php foreach (active_languages() as $l): if ($l['code'] === default_lang()) continue; ?>
                        <div class="mb-2">
                            <label class="form-label small">Nombre (<?= strtoupper($l['code']) ?>)</label>
                            <input type="text" name="name_trans[<?= $l['code'] ?>]" class="form-control form-control-sm"
                                value="<?= esc(old("name_trans.{$l['code']}", $name_trans[$l['code']]['name'] ?? '')) ?>">
                        </div>
                    <?php endforeach; ?>
                    <div class="mb-3">
                        <label class="form-label">Descripción</label>
                        <textarea name="description" class="form-control" rows="3"><?= old('description', $c['description'] ?? '') ?></textarea>
                    </div>
                    <div class="row g-2">
                        <div class="col-md-6">
                            <label class="form-label">Orden</label>
                            <input type="number" name="sort_order" class="form-control" value="<?= old('sort_order', $c['sort_order'] ?? 0) ?>">
                        </div>
                        <div class="col-md-6 d-flex align-items-end">
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" name="active" value="1" id="catActive" <?= old('active', $c['active'] ?? 1) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="catActive">Activa</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-end">
                    <button class="btn btn-primary"><i class="bi bi-check-lg"></i> Guardar</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $this->endSection() ?>