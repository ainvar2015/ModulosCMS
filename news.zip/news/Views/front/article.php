<?php $this->extend('front/themes/' . ($themePath ?? 'default') . '/layout') ?>

<?php $this->section('content') ?>
<?php
$pb = $pageBase ?? 'noticias';
$title = news_field($article, 'title');
$content = news_field($article, 'summary') . '<!-- more -->' . news_field($article, 'content');
?>

<div class="container py-5">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url() ?>">Inicio</a></li>
            <li class="breadcrumb-item"><a href="<?= localized_url($pb) ?>"><?= lang('News.title') ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= esc($title) ?></li>
        </ol>
    </nav>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="mb-2"><?= esc($title) ?></h1>
            <p class="text-muted mb-4">
                <?= news_date($article['published_at']) ?>
                <?php if (!empty($article['category_id'])): ?>
                    <?php $cat = (new \App\Modules\News\Models\NewsCategoryModel())->find($article['category_id']); ?>
                    <?php if ($cat): ?>
                        · <span class="badge bg-secondary"><?= esc(news_category_name($cat)) ?></span>
                    <?php endif; ?>
                <?php endif; ?>
            </p>

            <?php if (!empty($article['image_main'])): ?>
                <img src="<?= base_url($article['image_main']) ?>" class="img-fluid rounded shadow-sm mb-4 w-100" alt="<?= esc($title) ?>">
            <?php endif; ?>

            <div class="content">
                <?= news_field($article, 'content') ?>
            </div>

            <a href="<?= localized_url($pb) ?>" class="btn btn-outline-primary mt-4">
                <i class="bi bi-arrow-left"></i> <?= lang('News.back_to_news') ?>
            </a>
        </div>
    </div>

    <?php if (!empty($related)): ?>
        <hr class="my-5">
        <h2 class="h4 mb-4"><?= lang('News.related') ?></h2>
        <div class="row g-4">
            <?php foreach ($related as $r): ?>
                <div class="col-md-4">
                    <div class="card h-100 shadow-sm">
                        <?php if (!empty($r['image_main'])): ?>
                            <img src="<?= thumb_url($r['image_main']) ?>" class="card-img-top" style="height:180px;object-fit:cover;" alt="<?= esc(news_field($r, 'title')) ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <small class="text-muted"><?= news_date($r['published_at']) ?></small>
                            <h3 class="h6 mt-1"><?= esc(news_field($r, 'title')) ?></h3>
                            <a href="<?= localized_url($pb . '/noticia/' . $r['slug']) ?>" class="btn btn-outline-primary btn-sm"><?= lang('News.read_more') ?></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
<?php $this->endSection() ?>