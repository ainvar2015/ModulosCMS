<?php
// Parcial: listado de noticias. Sin layout (modo embed dentro de la página-módulo).
$pb = $pageBase ?? 'noticias';
$firstFeatured = !empty($featured) ? $featured[0] : null;
?>

<?php if (!empty($categories)): ?>
    <div class="d-flex justify-content-center gap-2 flex-wrap mb-4">
        <a href="<?= localized_url($pb) ?>" class="btn btn-sm btn-outline-secondary <?= empty($activeCat) ? 'active' : '' ?>">
            <?= lang('News.all') ?>
        </a>
        <?php foreach ($categories as $c): ?>
            <a href="<?= localized_url($pb . '?categoria=' . $c['slug']) ?>"
               class="btn btn-sm btn-outline-secondary <?= ($activeCat === $c['slug']) ? 'active' : '' ?> ms-1">
                <?= esc(news_category_name($c)) ?>
            </a>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if ($firstFeatured && empty($activeCat)): ?>
    <?php $fa = $firstFeatured; ?>
    <div class="card mb-4 shadow-sm">
        <div class="row g-0">
            <div class="col-md-6">
                <?php if (!empty($fa['image_main'])): ?>
                    <img src="<?= thumb_url($fa['image_main']) ?>" class="img-fluid rounded-start w-100" style="height:100%;object-fit:cover;min-height:260px;" alt="<?= esc(news_field($fa, 'title')) ?>">
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <div class="card-body d-flex flex-column h-100">
                    <span class="badge bg-success align-self-start mb-2"><?= lang('News.title') ?></span>
                    <h2 class="card-title h4"><?= esc(news_field($fa, 'title')) ?></h2>
                    <p class="card-text text-muted"><?= esc(mb_substr(strip_tags(news_field($fa, 'summary')), 0, 220)) ?>…</p>
                    <div class="mt-auto">
                        <small class="text-muted d-block mb-2"><?= news_date($fa['published_at']) ?></small>
                        <a href="<?= localized_url($pb . '/noticia/' . $fa['slug']) ?>" class="btn btn-primary"><?= lang('News.read_more') ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if (empty($articles)): ?>
    <div class="alert alert-info"><?= lang('News.no_articles') ?></div>
<?php else: ?>
    <div class="row g-4">
        <?php foreach ($articles as $a): if ($firstFeatured && empty($activeCat) && $a['id'] == $firstFeatured['id']) continue; ?>
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 shadow-sm">
                    <?php if (!empty($a['image_main'])): ?>
                        <img src="<?= thumb_url($a['image_main']) ?>" class="card-img-top" style="height:200px;object-fit:cover;" alt="<?= esc(news_field($a, 'title')) ?>">
                    <?php endif; ?>
                    <div class="card-body d-flex flex-column">
                        <small class="text-muted mb-1">
                            <?= news_date($a['published_at']) ?>
                            <?php if (!empty($a['category_id'])): ?>
                                <?php $cat = (new \App\Modules\News\Models\NewsCategoryModel())->find($a['category_id']); ?>
                                <?php if ($cat): ?>
                                    · <span class="badge bg-secondary"><?= esc(news_category_name($cat)) ?></span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </small>
                        <h3 class="card-title h5"><?= esc(news_field($a, 'title')) ?></h3>
                        <p class="card-text text-muted small"><?= esc(mb_substr(strip_tags(news_field($a, 'summary')), 0, 120)) ?>…</p>
                        <a href="<?= localized_url($pb . '/noticia/' . $a['slug']) ?>" class="btn btn-outline-primary btn-sm mt-auto align-self-start">
                            <?= lang('News.read_more') ?>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>