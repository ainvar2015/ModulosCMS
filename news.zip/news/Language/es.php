<?php
// es
return [
    'title'        => 'Noticias',
    'read_more'    => 'Leer más',
    'no_articles'  => 'No hay noticias disponibles.',
    'all'          => 'Todas',
    'categories'   => 'Categorías',
    'back_to_news' => 'Volver a noticias',
    'related'      => 'Noticias relacionadas',
];