<?php

return [
    'label'   => 'Noticias',
    'icon'    => 'bi-newspaper',
    'segment' => 'news',
    'items'   => [
        ['url' => 'admin/news/articles',   'label' => 'Artículos',  'icon' => 'bi-file-text'],
        ['url' => 'admin/news/categories', 'label' => 'Categorías', 'icon' => 'bi-tags'],
    ],
];