<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<?php $isEdit = !empty($f); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2"><?= esc($title) ?></h1>
    <a href="<?= base_url('admin/forms') ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Volver</a>
</div>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger"><ul class="mb-0">
        <?php foreach (session()->getFlashdata('errors') as $e): ?><li><?= $e ?></li><?php endforeach; ?>
    </ul></div>
<?php endif; ?>

<form action="<?= $action ?>" method="post" id="formBuilder">
    <?= csrf_field() ?>
    <div class="row g-4">
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nombre <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" required value="<?= old('name', $f['name'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Slug</label>
                        <input type="text" name="slug" class="form-control" value="<?= old('slug', $f['slug'] ?? '') ?>">
                        <div class="form-text">Vacío = se genera del nombre.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email de aviso</label>
                        <input type="email" name="email_to" class="form-control" value="<?= old('email_to', $f['email_to'] ?? '') ?>">
                        <div class="form-text">Recibe una copia de cada envío (requiere SMTP configurado).</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Mensaje de éxito</label>
                        <input type="text" name="success_message" class="form-control"
                            value="<?= old('success_message', $f['success_message'] ?? '') ?>"
                            placeholder="Mensaje enviado correctamente.">
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="active" value="1" id="act" <?= old('active', $f['active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="act">Activo</label>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100 mt-3">
                <i class="bi bi-check-lg"></i> Guardar formulario
            </button>
        </div>

        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Campos</h5>
                    <button type="button" class="btn btn-sm btn-outline-primary" id="addField">
                        <i class="bi bi-plus-lg"></i> Añadir campo
                    </button>
                </div>
                <div class="card-body" id="fieldsContainer">
                    <?php if (empty($fields)): ?>
                        <?= view('App\Modules\Forms\Views\admin\forms\_field_row', ['i' => 0, 'field' => null]) ?>
                    <?php else: foreach ($fields as $i => $field): ?>
                        <?= view('App\Modules\Forms\Views\admin\forms\_field_row', ['i' => $i, 'field' => $field]) ?>
                    <?php endforeach; endif; ?>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $this->endSection() ?>

<?php $this->section('js') ?>
<script>
    // Añadir fila de campo clonando la primera
    document.getElementById('addField').addEventListener('click', () => {
        const container = document.getElementById('fieldsContainer');
        const first = container.querySelector('.field-row');
        const clone = first.cloneNode(true);
        clone.querySelectorAll('input, select').forEach(el => {
            if (el.type === 'checkbox') el.checked = false;
            else el.value = '';
        });
        clone.querySelector('.options-wrap').classList.add('d-none');
        container.appendChild(clone);
        bindRemoveButtons();
    });

    function bindRemoveButtons() {
        document.querySelectorAll('.remove-field').forEach(btn => {
            btn.onclick = () => {
                const rows = document.querySelectorAll('.field-row');
                if (rows.length > 1) btn.closest('.field-row').remove();
            };
        });
        // Mostrar opciones solo si el tipo es select
        document.querySelectorAll('.field-type').forEach(sel => {
            sel.onchange = () => {
                sel.closest('.field-row').querySelector('.options-wrap')
                    .classList.toggle('d-none', sel.value !== 'select');
            };
        });
    }
    bindRemoveButtons();
</script>
<?php $this->endSection() ?>