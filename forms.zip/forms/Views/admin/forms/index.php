<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Formularios</h1>
    <a href="<?= base_url('admin/forms/create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Nuevo formulario
    </a>
</div>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-3">Nombre</th>
                    <th>Shortcode</th>
                    <th>Email aviso</th>
                    <th>Activo</th>
                    <th class="text-end pe-3">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($forms)): ?>
                    <tr><td colspan="5" class="text-center text-muted py-4">No hay formularios. Crea el primero.</td></tr>
                <?php else: foreach ($forms as $f): ?>
                    <tr>
                        <td class="ps-3"><strong><?= esc($f['name']) ?></strong></td>
                        <td><code>[formulario slug="<?= esc($f['slug']) ?>"]</code></td>
                        <td><?= esc($f['email_to'] ?: '—') ?></td>
                        <td>
                            <a href="<?= base_url('admin/forms/toggle/' . $f['id']) ?>"
                               class="btn btn-sm <?= $f['active'] ? 'btn-success' : 'btn-outline-secondary' ?>"><?= $f['active'] ? 'Sí' : 'No' ?></a>
                        </td>
                        <td class="text-end pe-3">
                            <a href="<?= base_url('admin/forms/entries/' . $f['id']) ?>" class="btn btn-sm btn-outline-secondary" title="Envíos">
                                <i class="bi bi-inbox"></i>
                            </a>
                            <a href="<?= base_url('admin/forms/edit/' . $f['id']) ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="<?= base_url('admin/forms/delete/' . $f['id']) ?>" method="post" class="d-inline"
                                onsubmit="return confirm('¿Eliminar este formulario y TODOS sus envíos?')">
                                <?= csrf_field() ?>
                                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $this->endSection() ?>