<?php
$types = ['text' => 'Texto', 'email' => 'Email', 'textarea' => 'Texto largo', 'select' => 'Desplegable', 'checkbox' => 'Casilla', 'number' => 'Número', 'date' => 'Fecha'];
$type  = $field['type'] ?? 'text';
?>
<div class="field-row border rounded p-3 mb-3 bg-light">
    <div class="row g-2 align-items-end">
        <div class="col-md-4">
            <label class="form-label small mb-1">Etiqueta <span class="text-danger">*</span></label>
            <input type="text" name="field_label[]" class="form-control form-control-sm" value="<?= esc($field['label'] ?? '') ?>" required>
        </div>
        <div class="col-md-2">
            <label class="form-label small mb-1">Nombre interno</label>
            <input type="text" name="field_name[]" class="form-control form-control-sm" value="<?= esc($field['name'] ?? '') ?>" placeholder="auto">
        </div>
        <div class="col-md-3">
            <label class="form-label small mb-1">Tipo</label>
            <select name="field_type[]" class="form-select form-select-sm field-type">
                <?php foreach ($types as $k => $t): ?>
                    <option value="<?= $k ?>" <?= $type === $k ? 'selected' : '' ?>><?= $t ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2 form-check ms-2 mb-1">
            <input class="form-check-input" type="checkbox" name="field_required[<?= $i ?>]" value="1" id="req<?= $i ?>" <?= !empty($field['required']) ? 'checked' : '' ?>>
            <label class="form-check-label small" for="req<?= $i ?>">Obligatorio</label>
        </div>
        <div class="col-md-1 text-end mb-1">
            <button type="button" class="btn btn-sm btn-outline-danger remove-field"><i class="bi bi-x-lg"></i></button>
        </div>
        <div class="col-12 options-wrap <?= $type === 'select' ? '' : 'd-none' ?>">
            <label class="form-label small mb-1">Opciones (una por línea)</label>
            <textarea name="field_options[]" class="form-control form-control-sm" rows="2"><?= esc($field['options'] ?? '') ?></textarea>
        </div>
    </div>
</div>