<?php

namespace App\Modules\Forms\Models;

use CodeIgniter\Model;

class FormModel extends Model
{
    protected $table         = 'forms';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['name', 'slug', 'email_to', 'success_message', 'active'];
    protected $useTimestamps = true;
}