<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateFormsTables extends Migration
{
    public function up()
    {
        // Formularios
        $this->forge->addField([
            'id'             => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'name'           => ['type' => 'VARCHAR', 'constraint' => 150],
            'slug'           => ['type' => 'VARCHAR', 'constraint' => 190],
            'email_to'       => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'success_message'=> ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'active'         => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'created_at'     => ['type' => 'DATETIME', 'null' => true],
            'updated_at'     => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('slug', false, true);
        $this->forge->createTable('forms');

        // Campos
        $this->forge->addField([
            'id'         => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'form_id'    => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'label'      => ['type' => 'VARCHAR', 'constraint' => 150],
            'name'       => ['type' => 'VARCHAR', 'constraint' => 100],
            'type'       => ['type' => 'ENUM', 'constraint' => ['text', 'email', 'textarea', 'select', 'checkbox', 'number', 'date']],
            'options'    => ['type' => 'TEXT', 'null' => true],   // JSON para select
            'required'   => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0],
            'sort_order' => ['type' => 'INT', 'constraint' => 11, 'default' => 0],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('form_id');
        $this->forge->createTable('form_fields');

        // Envíos
        $this->forge->addField([
            'id'         => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'form_id'    => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'data'       => ['type' => 'JSON', 'null' => true],
            'read'       => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0],
            'created_at' => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('form_id');
        $this->forge->createTable('form_entries');
    }

    public function down()
    {
        $this->forge->dropTable('form_entries');
        $this->forge->dropTable('form_fields');
        $this->forge->dropTable('forms');
    }
}