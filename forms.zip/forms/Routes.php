<?php

use App\Modules\Forms\Controllers\Admin\Forms as AdminForms;
use App\Modules\Forms\Controllers\Front\Forms as FrontForms;

// Admin
$routes->group('admin/forms', ['filter' => 'auth'], function ($routes) {
    $routes->get('/', [AdminForms::class, 'index']);
    $routes->get('create', [AdminForms::class, 'create']);
    $routes->post('store', [AdminForms::class, 'store']);
    $routes->get('edit/(:num)', [AdminForms::class, 'edit/$1']);
    $routes->post('update/(:num)', [AdminForms::class, 'update/$1']);
    $routes->post('delete/(:num)', [AdminForms::class, 'delete/$1']);
    $routes->get('toggle/(:num)', [AdminForms::class, 'toggle/$1']);

    // Envíos
    $routes->get('entries/(:num)', [AdminForms::class, 'entries/$1']);
    $routes->get('entries', [AdminForms::class, 'entries']);
    $routes->post('entries/read/(:num)', [AdminForms::class, 'markRead/$1']);
    $routes->post('entries/delete/(:num)', [AdminForms::class, 'deleteEntry/$1']);
});

// Front: envío del formulario (shortcode, no página-módulo)
$routes->post('forms/submit/(:any)', [FrontForms::class, 'submit/$1']);