<?php

return [
    'label'   => 'Formularios',
    'icon'    => 'bi-ui-checks',
    'segment' => 'forms',
    'items'   => [
        ['url' => 'admin/forms',   'label' => 'Formularios', 'icon' => 'bi-ui-checks-grid'],
        ['url' => 'admin/forms/entries', 'label' => 'Envíos', 'icon' => 'bi-inbox'],
    ],
];