<?php
// es
return [
    'submit'      => 'Enviar',
    'required'    => 'Los campos marcados con * son obligatorios.',
    'success'     => 'Mensaje enviado correctamente.',
    'error'       => 'Ha habido un error al enviar. Revisa los campos.',
];