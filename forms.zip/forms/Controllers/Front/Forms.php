<?php

namespace App\Modules\Forms\Controllers\Front;

use App\Controllers\BaseController;
use App\Modules\Forms\Models\FormModel;
use App\Modules\Forms\Models\FormFieldModel;
use App\Modules\Forms\Models\FormEntryModel;

class Forms extends BaseController
{
    protected $helpers = ['url', 'form', 'html', 'i18n'];

    public function submit($slug)
    {
        $formModel = new FormModel();
        $form      = $formModel->where('slug', $slug)->where('active', 1)->first();

        if (!$form) {
            return redirect()->to(base_url());
        }

        $fieldModel = new FormFieldModel();
        $fields     = $fieldModel->getByForm((int) $form['id']);

        // Reglas dinámicas según campos
        $rules = [];
        foreach ($fields as $f) {
            $r = [];
            if ($f['required']) {
                $r[] = 'required';
                if ($f['type'] === 'checkbox') $r[] = 'in_list[1]';
            } else {
                $r[] = 'permit_empty';
            }
            if ($f['type'] === 'email') $r[] = 'valid_email';
            if ($f['type'] === 'number') $r[] = 'numeric';
            if ($f['type'] === 'select' && !empty($f['options'])) {
                $opts = array_filter(array_map('trim', explode("\n", $f['options'])));
                if ($opts) $r[] = 'in_list[' . implode(',', $opts) . ']';
            }
            if ($r) $rules[$f['name']] = implode('|', $r);
        }

        // Honeypot anti-spam: campo "website" que debe quedar vacío
        if ($this->request->getPost('website') !== null && $this->request->getPost('website') !== '') {
            return redirect()->back();
        }

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()
                ->with('form_error_' . $form['slug'], lang('Forms.error'))
                ->with('errors', $this->validator->getErrors());
        }

        // Guardar envío
        $data = [];
        foreach ($fields as $f) {
            $val = $this->request->getPost($f['name']);
            if (is_array($val)) $val = implode(', ', $val);
            $data[$f['label']] = $val ?? '';
        }

        (new FormEntryModel())->insert([
            'form_id' => $form['id'],
            'data'    => json_encode($data, JSON_UNESCAPED_UNICODE),
            'read'    => 0,
        ]);

        // Email de aviso (opcional; silencioso si no hay SMTP)
        if (!empty($form['email_to'])) {
            try {
                $email = \Config\Services::email();
                $email->setTo($form['email_to']);
                $email->setSubject('Nuevo envío: ' . $form['name']);
                $body = "Formulario: {$form['name']}\n\n";
                foreach ($data as $k => $v) $body .= "$k: $v\n";
                $email->setMessage($body);
                $email->send();
            } catch (\Throwable $e) {
                log_message('error', '[forms] email aviso: ' . $e->getMessage());
            }
        }

        return redirect()->back()
            ->with('form_success_' . $form['slug'], $form['success_message'] ?: lang('Forms.success'));
    }
}