<?php

namespace App\Modules\Catalog\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table      = 'catalog_products';
    protected $primaryKey = 'id';
    protected $allowedFields = ['category_id','name','slug','sku','description','short_desc','price','price_old','stock','image_main','images_gallery','featured','active','meta_title','meta_desc'];
    protected $useTimestamps = true;

        public function getActive($categoryId = null, $featured = null, $limit = null)
    {
        $builder = $this->where('active', 1)->orderBy('id', 'DESC');
        
        if ($categoryId) {
            $builder->where('category_id', $categoryId);
        }
        if ($featured !== null) {
            $builder->where('featured', $featured ? 1 : 0);
        }
        if ($limit) {
            $builder->limit((int) $limit);
        }
        
        return $builder->findAll();
    }

    public function getBySlug($slug)
    {
        return $this->where('slug', $slug)->where('active', 1)->first();
    }

    public function getWithCategory($slug)
    {
        $builder = $this->db->table('catalog_products p');
        $builder->select('p.*, c.name as category_name, c.slug as category_slug');
        $builder->join('catalog_categories c', 'c.id = p.category_id', 'left');
        $builder->where('p.slug', $slug);
        $builder->where('p.active', 1);
        return $builder->get()->getRowArray();
    }
}