<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<?php $isEdit = !empty($product); $p = $product ?? []; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2"><?= $title ?></h1>
    <a href="<?= base_url('admin/catalog/products') ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Volver</a>
</div>

<form action="<?= $action ?>" method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nombre *</label>
                        <input type="text" name="name" class="form-control" value="<?= old('name', $p['name'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Slug</label>
                        <input type="text" name="slug" class="form-control" value="<?= old('slug', $p['slug'] ?? '') ?>">
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Precio *</label>
                            <input type="number" step="0.01" name="price" class="form-control" value="<?= old('price', $p['price'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Precio anterior</label>
                            <input type="number" step="0.01" name="price_old" class="form-control" value="<?= old('price_old', $p['price_old'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Stock *</label>
                            <input type="number" name="stock" class="form-control" value="<?= old('stock', $p['stock'] ?? 0) ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">SKU</label>
                        <input type="text" name="sku" class="form-control" value="<?= old('sku', $p['sku'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Descripción corta</label>
                        <input type="text" name="short_desc" class="form-control" maxlength="500" value="<?= old('short_desc', $p['short_desc'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Descripción larga</label>
                        <textarea name="description" class="form-control" rows="5"><?= old('description', $p['description'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm mb-3">
                <div class="card-header bg-white">Imágenes</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Imagen principal</label>
                        <input type="file" name="image_main" class="form-control" accept="image/*">
                        <?php if (!empty($p['image_main'])): ?>
                            <img src="<?= base_url($p['image_main']) ?>" height="80" class="mt-2 img-thumbnail">
                        <?php endif; ?>
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Galería (múltiples)</label>
                        <input type="file" name="gallery[]" class="form-control" accept="image/*" multiple>
                        <?php 
                        $gallery = json_decode($p['images_gallery'] ?? '[]', true) ?: [];
                        foreach ($gallery as $img): ?>
                            <img src="<?= base_url($img) ?>" height="60" class="mt-2 me-1 img-thumbnail">
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card shadow-sm mb-3">
                <div class="card-header bg-white">Opciones</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Categoría</label>
                        <select name="category_id" class="form-select">
                            <option value="">Sin categoría</option>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= $c['id'] ?>" <?= old('category_id', $p['category_id'] ?? '') == $c['id'] ? 'selected' : '' ?>><?= esc($c['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" name="featured" value="1" id="feat" <?= old('featured', $p['featured'] ?? 0) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="feat">Destacado</label>
                    </div>
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input" type="checkbox" name="active" value="1" id="act" <?= old('active', $p['active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="act">Activo</label>
                    </div>
                </div>
                <div class="card-footer text-end">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Guardar</button>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-header bg-white">SEO</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Meta título</label>
                        <input type="text" name="meta_title" class="form-control" value="<?= old('meta_title', $p['meta_title'] ?? '') ?>">
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Meta descripción</label>
                        <textarea name="meta_desc" class="form-control" rows="2"><?= old('meta_desc', $p['meta_desc'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $this->endSection() ?>