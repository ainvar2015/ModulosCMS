<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Productos</h1>
    <div>
        <a href="<?= base_url('admin/catalog/categories') ?>" class="btn btn-outline-secondary me-2">Categorías</a>
        <a href="<?= base_url('admin/catalog/products/import') ?>" class="btn btn-outline-success me-2"><i class="bi bi-upload"></i> Importar CSV</a>
        <a href="<?= base_url('admin/catalog/products/create') ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Nuevo</a>
    </div>
</div>

<form method="get" class="row g-2 mb-3">
    <div class="col-md-3">
        <select name="category_id" class="form-select" onchange="this.form.submit()">
            <option value="">Todas las categorías</option>
            <?php foreach ($categories as $c): ?>
                <option value="<?= $c['id'] ?>" <?= ($catFilter == $c['id']) ? 'selected' : '' ?>><?= esc($c['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Buscar..." value="<?= esc($search) ?>">
            <button class="btn btn-outline-secondary" type="submit"><i class="bi bi-search"></i></button>
        </div>
    </div>
</form>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Imagen</th>
                    <th>Nombre / SKU</th>
                    <th>Categoría</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Dest.</th>
                    <th>Act.</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $p): ?>
                    <tr>
                        <td>
                            <?php if ($p['image_main']): ?>
                                <img src="<?= base_url($p['image_main']) ?>" height="50" class="rounded">
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= esc($p['name']) ?></strong>
                            <?php if ($p['sku']): ?><br><small class="text-muted">SKU: <?= esc($p['sku']) ?></small><?php endif; ?>
                        </td>
                        <td><?= esc($p['category_name']) ?></td>
                        <td>
                            <span class="fw-bold text-primary"><?= number_format($p['price'], 2, ',', '.') ?> €</span>
                            <?php if ($p['price_old']): ?>
                                <br><small class="text-muted text-decoration-line-through"><?= number_format($p['price_old'], 2, ',', '.') ?> €</small>
                            <?php endif; ?>
                        </td>
                        <td><?= $p['stock'] ?></td>
                        <td><?= $p['featured'] ? '<i class="bi bi-star-fill text-warning"></i>' : '—' ?></td>
                        <td>
                            <a href="<?= base_url('admin/catalog/products/toggle/' . $p['id']) ?>" class="badge bg-<?= $p['active'] ? 'success' : 'secondary' ?>">
                                <?= $p['active'] ? 'Sí' : 'No' ?>
                            </a>
                        </td>
                        <td class="text-end">
                            <a href="<?= base_url('catalogo/producto/' . $p['slug']) ?>" target="_blank" class="btn btn-sm btn-outline-success"><i class="bi bi-eye"></i></a>
                            <a href="<?= base_url('admin/catalog/products/edit/' . $p['id']) ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                            <a href="<?= base_url('admin/catalog/products/delete/' . $p['id']) ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Eliminar?')"><i class="bi bi-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if ($pager): ?>
        <div class="card-footer"><?= $pager->links('products', 'bootstrap5') ?></div>
    <?php endif; ?>
</div>
<?php $this->endSection() ?>