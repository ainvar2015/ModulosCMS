<?php $this->extend('front/themes/' . ($themePath ?? 'default') . '/layout') ?>

<?php $this->section('content') ?>
<div class="row">
    <div class="col-lg-3 mb-4">
        <div class="card shadow-sm">
            <div class="card-header bg-white"><h5 class="mb-0">Categorías</h5></div>
            <div class="list-group list-group-flush">
                <a href="<?= base_url('catalogo') ?>" class="list-group-item list-group-item-action <?= empty($activeCat) ? 'active' : '' ?>">Todas</a>
                <?php foreach ($categories as $c): ?>
                    <a href="<?= base_url('catalogo?categoria=' . $c['slug']) ?>" class="list-group-item list-group-item-action <?= ($activeCat == $c['slug']) ? 'active' : '' ?>"><?= esc($c['name']) ?></a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-9">
        <h1 class="mb-4">Catálogo</h1>
        <?php if (empty($products)): ?>
            <div class="alert alert-info">No hay productos disponibles.</div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($products as $p):
                    $gallery = json_decode($p['images_gallery'] ?? '[]', true) ?: [];
                ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100 shadow-sm">
                            <?php if ($p['image_main']): ?>
                                <img src="<?= base_url($p['image_main']) ?>" class="card-img-top" style="height:200px;object-fit:cover;">
                            <?php else: ?>
                                <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height:200px;"><i class="bi bi-box-seam text-muted" style="font-size:3rem;"></i></div>
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title"><?= esc($p['name']) ?></h5>
                                <p class="card-text text-muted small"><?= esc($p['short_desc']) ?></p>
                                <p class="card-text">
                                    <span class="fw-bold text-primary fs-5"><?= number_format($p['price'], 2, ',', '.') ?> €</span>
                                    <?php if ($p['price_old'] && $p['price_old'] > $p['price']): ?>
                                        <span class="text-muted text-decoration-line-through"><?= number_format($p['price_old'], 2, ',', '.') ?> €</span>
                                    <?php endif; ?>
                                </p>
                                <a href="<?= base_url('catalogo/producto/' . $p['slug']) ?>" class="btn btn-outline-primary btn-sm">Ver ficha</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $this->endSection() ?>