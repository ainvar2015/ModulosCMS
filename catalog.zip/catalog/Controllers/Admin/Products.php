<?php

namespace App\Modules\Catalog\Controllers\Admin;

use App\Controllers\Admin\BaseController;
use App\Modules\Catalog\Models\ProductModel;
use App\Modules\Catalog\Models\CategoryModel;

class Products extends BaseController
{
    protected $helpers = ['url', 'form', 'html'];

    protected function renderModule(string $view, array $data = [])
    {
        return view('App\Modules\Catalog\Views\admin\\' . $view, array_merge($this->data, $data));
    }

    public function index()
    {
        $productModel = new ProductModel();
        $categoryModel = new CategoryModel();

        $categoryFilter = $this->request->getGet('category_id');
        $search = $this->request->getGet('search');

        $builder = $productModel->orderBy('id', 'DESC');

        if ($categoryFilter) {
            $builder->where('category_id', $categoryFilter);
        }
        if ($search) {
            $builder->groupStart()
                ->like('name', $search)
                ->orLike('sku', $search)
                ->orLike('description', $search)
                ->groupEnd();
        }

        $products = $builder->paginate(20, 'products');
        $categories = $categoryModel->findAll();

        // Añadir nombre de categoría a cada producto
        $catMap = array_column($categories, 'name', 'id');
        foreach ($products as &$p) {
            $p['category_name'] = $catMap[$p['category_id']] ?? 'Sin categoría';
        }

        return $this->renderModule('products/index', [
            'title'      => 'Productos',
            'products'   => $products,
            'pager'      => $productModel->pager,
            'categories' => $categories,
            'catFilter'  => $categoryFilter,
            'search'     => $search,
        ]);
    }

    /**------------------------------------------------------------------------
     *   IMPORTACIÓN MASIVA DESDE CSV
     * ----------------------------------------------------------------------*/

    public function importForm()
    {
        $categoryModel = new CategoryModel();
        return $this->renderModule('products/import', [
            'title'      => 'Importar productos (CSV)',
            'categories' => $categoryModel->getActive(),
        ]);
    }

    public function import()
    {
        $rules = [
            'csv_file' => 'uploaded[csv_file]|ext_in[csv_file,csv]|max_size[csv_file,2048]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->with('error', 'Archivo inválido. Debe ser un CSV de máximo 2MB.');
        }

        $file = $this->request->getFile('csv_file');
        $handle = fopen($file->getTempName(), 'r');

        if (!$handle) {
            return redirect()->back()->with('error', 'No se pudo leer el archivo.');
        }

        $productModel = new ProductModel();
        $categoryModel = new CategoryModel();
        $defaultCategory = $this->request->getPost('default_category_id') ?: null;

        // Leer cabecera
        $header = fgetcsv($handle, 0, ';');
        if (!$header) {
            fclose($handle);
            return redirect()->back()->with('error', 'El CSV está vacío o no tiene cabecera.');
        }

        $created = 0;
        $errors = 0;

        while (($row = fgetcsv($handle, 0, ';')) !== false) {
            if (count($row) < 2) continue; // saltar líneas vacías

            $data = array_combine($header, $row);
            if ($data === false) continue;

            $name = trim($data['name'] ?? '');
            if (empty($name)) continue;

            // slugify sanea tanto el slug escrito a mano como el generado del nombre
            $slug = slugify($this->request->getPost('slug') ?: $this->request->getPost('name'));
            $slug = $this->ensureUniqueSlug($slug);

            $categoryId = !empty($data['category_id']) ? (int) $data['category_id'] : $defaultCategory;

            try {
                $productModel->insert([
                    'category_id'    => $categoryId,
                    'name'           => $name,
                    'slug'           => $slug,
                    'sku'            => $data['sku'] ?? null,
                    'description'    => $data['description'] ?? null,
                    'short_desc'     => $data['short_desc'] ?? null,
                    'price'          => isset($data['price']) ? (float) str_replace(',', '.', $data['price']) : 0,
                    'price_old'      => isset($data['price_old']) ? (float) str_replace(',', '.', $data['price_old']) : null,
                    'stock'          => isset($data['stock']) ? (int) $data['stock'] : 0,
                    'featured'       => (int) ($data['featured'] ?? 0),
                    'active'         => (int) ($data['active'] ?? 1),
                    'meta_title'     => $data['meta_title'] ?? null,
                    'meta_desc'      => $data['meta_desc'] ?? null,
                ]);
                $created++;
            } catch (\Exception $e) {
                $errors++;
                log_message('error', 'Error importando producto: ' . $e->getMessage());
            }
        }

        fclose($handle);

        $msg = "Importación completa. Creados: {$created}. Errores: {$errors}.";
        return redirect()->to('/admin/catalog/products')->with('success', $msg);
    }

    public function create()
    {
        $categoryModel = new CategoryModel();
        return $this->renderModule('products/form', [
            'title'      => 'Nuevo Producto',
            'product'    => null,
            'categories' => $categoryModel->getActive(),
            'action'     => base_url('admin/catalog/products/store'),
        ]);
    }

    public function store()
    {
        $rules = [
            'name'  => 'required|min_length[2]|max_length[255]',
            'slug'  => 'permit_empty|max_length[255]',
            'price' => 'required|decimal',
            'stock' => 'required|integer',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $productModel = new ProductModel();
        // slugify sanea tanto el slug escrito a mano como el generado del nombre
        $slug = slugify($this->request->getPost('slug') ?: $this->request->getPost('name'));
        $slug = $this->ensureUniqueSlug($slug);

        $gallery = [];
        $files = $this->request->getFiles();
        if (!empty($files['gallery'])) {
            foreach ($files['gallery'] as $file) {
                if ($file && $file->isValid() && !$file->hasMoved()) {
                    $newName = $file->getRandomName();
                    $file->move(ROOTPATH . 'public/uploads/catalog', $newName);
                    $gallery[] = 'uploads/catalog/' . $newName;
                }
            }
        }

        $mainImage = null;
        $mainFile = $this->request->getFile('image_main');
        if ($mainFile && $mainFile->isValid() && !$mainFile->hasMoved()) {
            $newName = $mainFile->getRandomName();
            $mainFile->move(ROOTPATH . 'public/uploads/catalog', $newName);
            $mainImage = 'uploads/catalog/' . $newName;
        }

        $productModel->insert([
            'category_id'    => $this->request->getPost('category_id') ?: null,
            'name'           => $this->request->getPost('name'),
            'slug'           => $slug,
            'sku'            => $this->request->getPost('sku'),
            'description'    => $this->request->getPost('description'),
            'short_desc'     => $this->request->getPost('short_desc'),
            'price'          => $this->request->getPost('price'),
            'price_old'      => $this->request->getPost('price_old') ?: null,
            'stock'          => (int) $this->request->getPost('stock'),
            'image_main'     => $mainImage,
            'images_gallery' => !empty($gallery) ? json_encode($gallery) : null,
            'featured'       => $this->request->getPost('featured') ? 1 : 0,
            'active'         => $this->request->getPost('active') ? 1 : 0,
            'meta_title'     => $this->request->getPost('meta_title'),
            'meta_desc'      => $this->request->getPost('meta_desc'),
        ]);

        return redirect()->to('/admin/catalog/products')->with('success', 'Producto creado.');
    }

    public function edit($id)
    {
        $productModel = new ProductModel();
        $categoryModel = new CategoryModel();
        $product = $productModel->find($id);

        if (!$product) {
            return redirect()->to('/admin/catalog/products')->with('error', 'Producto no encontrado.');
        }

        return $this->renderModule('products/form', [
            'title'      => 'Editar Producto',
            'product'    => $product,
            'categories' => $categoryModel->getActive(),
            'action'     => base_url('admin/catalog/products/update/' . $id),
        ]);
    }

    public function update($id)
    {
        $productModel = new ProductModel();
        $product = $productModel->find($id);

        if (!$product) {
            return redirect()->to('/admin/catalog/products')->with('error', 'Producto no encontrado.');
        }

        $rules = [
            'name'  => 'required|min_length[2]|max_length[255]',
            'slug'  => "permit_empty|max_length[255]|is_unique[catalog_products.slug,id,{$id}]",
            'price' => 'required|decimal',
            'stock' => 'required|integer',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // slugify sanea tanto el slug escrito a mano como el generado del nombre
        $slug = slugify($this->request->getPost('slug') ?: $this->request->getPost('name'));
        if ($slug !== $product['slug']) $slug = $this->ensureUniqueSlug($slug, $id);


        $data = [
            'category_id'    => $this->request->getPost('category_id') ?: null,
            'name'           => $this->request->getPost('name'),
            'slug'           => $slug,
            'sku'            => $this->request->getPost('sku'),
            'description'    => $this->request->getPost('description'),
            'short_desc'     => $this->request->getPost('short_desc'),
            'price'          => $this->request->getPost('price'),
            'price_old'      => $this->request->getPost('price_old') ?: null,
            'stock'          => (int) $this->request->getPost('stock'),
            'featured'       => $this->request->getPost('featured') ? 1 : 0,
            'active'         => $this->request->getPost('active') ? 1 : 0,
            'meta_title'     => $this->request->getPost('meta_title'),
            'meta_desc'      => $this->request->getPost('meta_desc'),
        ];

        // Imagen principal
        $mainFile = $this->request->getFile('image_main');
        if ($mainFile && $mainFile->isValid() && !$mainFile->hasMoved()) {
            $newName = $mainFile->getRandomName();
            $mainFile->move(ROOTPATH . 'public/uploads/catalog', $newName);
            $data['image_main'] = 'uploads/catalog/' . $newName;
        }

        // Galería (añadir a existente)
        $gallery = json_decode($product['images_gallery'] ?? '[]', true) ?: [];
        $files = $this->request->getFiles();
        if (!empty($files['gallery'])) {
            foreach ($files['gallery'] as $file) {
                if ($file && $file->isValid() && !$file->hasMoved()) {
                    $newName = $file->getRandomName();
                    $file->move(ROOTPATH . 'public/uploads/catalog', $newName);
                    $gallery[] = 'uploads/catalog/' . $newName;
                }
            }
        }
        $data['images_gallery'] = !empty($gallery) ? json_encode($gallery) : null;

        $productModel->update($id, $data);
        return redirect()->to('/admin/catalog/products')->with('success', 'Producto actualizado.');
    }

    public function delete($id)
    {
        $productModel = new ProductModel();
        $product = $productModel->find($id);

        if (!$product) {
            return redirect()->to('/admin/catalog/products')->with('error', 'Producto no encontrado.');
        }

        // Borrar imágenes
        if (!empty($product['image_main'])) {
            @unlink(ROOTPATH . 'public/' . $product['image_main']);
        }
        $gallery = json_decode($product['images_gallery'] ?? '[]', true) ?: [];
        foreach ($gallery as $img) {
            @unlink(ROOTPATH . 'public/' . $img);
        }

        $productModel->delete($id);
        return redirect()->to('/admin/catalog/products')->with('success', 'Producto eliminado.');
    }

    public function toggle($id)
    {
        $productModel = new ProductModel();
        $product = $productModel->find($id);
        if (!$product) return redirect()->back()->with('error', 'No encontrado.');

        $productModel->update($id, ['active' => $product['active'] ? 0 : 1]);
        return redirect()->back()->with('success', 'Estado cambiado.');
    }

    /* ------------------------------------------------- */
    // private function generateSlug(string $text): string
    // {
    //     $text = strtolower($text);
    //     $text = iconv('UTF-8', 'ASCII//TRANSLIT', $text);
    //     $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
    //     $text = preg_replace('/[\s-]+/', '-', $text);
    //     return trim($text, '-');
    // }

    private function ensureUniqueSlug(string $slug, ?int $excludeId = null): string
    {
        $model = new ProductModel();
        $original = $slug;
        $counter = 1;
        while (true) {
            $builder = $model->where('slug', $slug);
            if ($excludeId) $builder->where('id !=', $excludeId);
            if (!$builder->first()) break;
            $slug = $original . '-' . $counter++;
        }
        return $slug;
    }
}
