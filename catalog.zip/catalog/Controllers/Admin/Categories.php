<?php

namespace App\Modules\Catalog\Controllers\Admin;

use App\Controllers\Admin\BaseController;
use App\Modules\Catalog\Models\CategoryModel;

class Categories extends BaseController
{
    protected $helpers = ['url', 'form', 'html'];

    protected function renderModule(string $view, array $data = [])
    {
        return view('App\Modules\Catalog\Views\admin\\' . $view, array_merge($this->data, $data));
    }

    public function index()
    {
        $model = new CategoryModel();
        return $this->renderModule('categories/index', [
            'title'      => 'Categorías',
            'categories' => $model->orderBy('sort_order', 'ASC')->findAll(),
        ]);
    }

    public function create()
    {
        return $this->renderModule('categories/form', [
            'title'    => 'Nueva Categoría',
            'category' => null,
            'action'   => base_url('admin/catalog/categories/store'),
        ]);
    }

    public function store()
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'slug' => 'permit_empty|max_length[100]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $model = new CategoryModel();
        // slugify sanea tanto el slug escrito a mano como el generado del nombre
        $slug = slugify($this->request->getPost('slug') ?: $this->request->getPost('name'));
        $slug = $this->ensureUniqueSlug($slug);

        $image = null;
        $file = $this->request->getFile('image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move(ROOTPATH . 'public/uploads/catalog', $newName);
            $image = 'uploads/catalog/' . $newName;
        }

        $model->insert([
            'name'        => $this->request->getPost('name'),
            'slug'        => $slug,
            'description' => $this->request->getPost('description'),
            'image'       => $image,
            'sort_order'  => (int) ($this->request->getPost('sort_order') ?: 0),
            'active'      => $this->request->getPost('active') ? 1 : 0,
        ]);

        return redirect()->to('/admin/catalog/categories')->with('success', 'Categoría creada.');
    }

    public function edit($id)
    {
        $model = new CategoryModel();
        $cat = $model->find($id);
        if (!$cat) return redirect()->to('/admin/catalog/categories')->with('error', 'No encontrada.');

        return $this->renderModule('categories/form', [
            'title'    => 'Editar Categoría',
            'category' => $cat,
            'action'   => base_url('admin/catalog/categories/update/' . $id),
        ]);
    }

    public function update($id)
    {
        $model = new CategoryModel();
        $cat = $model->find($id);
        if (!$cat) return redirect()->to('/admin/catalog/categories')->with('error', 'No encontrada.');

        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'slug' => "permit_empty|max_length[100]|is_unique[catalog_categories.slug,id,{$id}]",
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // slugify sanea tanto el slug escrito a mano como el generado del nombre
        $slug = slugify($this->request->getPost('slug') ?: $this->request->getPost('name'));
        if ($slug !== $cat['slug']) $slug = $this->ensureUniqueSlug($slug, $id);


        $data = [
            'name'        => $this->request->getPost('name'),
            'slug'        => $slug,
            'description' => $this->request->getPost('description'),
            'sort_order'  => (int) ($this->request->getPost('sort_order') ?: 0),
            'active'      => $this->request->getPost('active') ? 1 : 0,
        ];

        $file = $this->request->getFile('image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move(ROOTPATH . 'public/uploads/catalog', $newName);
            $data['image'] = 'uploads/catalog/' . $newName;
        }

        $model->update($id, $data);
        return redirect()->to('/admin/catalog/categories')->with('success', 'Categoría actualizada.');
    }

    public function delete($id)
    {
        $model = new CategoryModel();
        $cat = $model->find($id);
        if (!$cat) return redirect()->to('/admin/catalog/categories')->with('error', 'No encontrada.');

        if (!empty($cat['image'])) @unlink(ROOTPATH . 'public/' . $cat['image']);
        $model->delete($id);
        return redirect()->to('/admin/catalog/categories')->with('success', 'Categoría eliminada.');
    }

    /* ------------------------------------------------- */
    private function generateSlug(string $text): string
    {
        $text = strtolower($text);
        $text = iconv('UTF-8', 'ASCII//TRANSLIT', $text);
        $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
        $text = preg_replace('/[\s-]+/', '-', $text);
        return trim($text, '-');
    }

    private function ensureUniqueSlug(string $slug, ?int $excludeId = null): string
    {
        $model = new CategoryModel();
        $original = $slug;
        $counter = 1;
        while (true) {
            $builder = $model->where('slug', $slug);
            if ($excludeId) $builder->where('id !=', $excludeId);
            if (!$builder->first()) break;
            $slug = $original . '-' . $counter++;
        }
        return $slug;
    }
}
