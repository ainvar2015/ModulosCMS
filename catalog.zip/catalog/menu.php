<?php

return [
    'label'   => 'Catálogo',
    'icon'    => 'bi-shop',
    'segment' => 'catalog', // para detectar activo
    'items'   => [
        [
            'label' => 'Productos',
            'url'   => 'admin/catalog/products',
            'icon'  => 'bi-box-seam',
        ],
        [
            'label' => 'Categorías',
            'url'   => 'admin/catalog/categories',
            'icon'  => 'bi-tags',
        ],
    ],
];