<?php

namespace App\Modules\Gallery\Models;

use CodeIgniter\Model;

class ImageModel extends Model
{
    protected $table      = 'gallery_images';
    protected $primaryKey = 'id';
    protected $allowedFields = ['title','slug','description','album','file_path','sort_order','active'];
    protected $useTimestamps = false;
    protected $createdField = 'created_at';

    public function getActive($album = null, $limit = null)
    {
        $builder = $this->where('active', 1)->orderBy('sort_order', 'ASC')->orderBy('id', 'DESC');
        if ($album) $builder->where('album', $album);
        if ($limit) $builder->limit((int) $limit);
        return $builder->findAll();
    }

    public function getAlbums()
    {
        return $this->select('album, COUNT(*) as total')
                    ->where('active', 1)
                    ->where('album IS NOT NULL')
                    ->groupBy('album')
                    ->findAll();
    }
}