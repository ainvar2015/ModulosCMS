<?php

use App\Modules\Gallery\Controllers\Admin\Gallery as AdminGallery;
use App\Modules\Gallery\Controllers\Front\Gallery as FrontGallery;

// Admin
$routes->group('admin/gallery', ['filter' => 'auth'], function($routes) {
    $routes->get('images', [AdminGallery::class, 'index']);
    $routes->get('images/create', [AdminGallery::class, 'create']);
    $routes->post('images/store', [AdminGallery::class, 'store']);
    $routes->post('images/store-from-library', [AdminGallery::class, 'storeFromLibrary']);
    $routes->post('images/delete/(:num)', [AdminGallery::class, 'delete/$1']);

    $routes->get('album-translations', [AdminGallery::class, 'albumTranslations']);
    $routes->post('save-album-translations', [AdminGallery::class, 'saveAlbumTranslations']);
    $routes->post('images/toggle/(:num)', [AdminGallery::class, 'toggle/$1']);
});

// Front - Array callable
// $routes->get('galeria', [FrontGallery::class, 'index']);
// $routes->get('galeria/album/(:any)', [FrontGallery::class, 'album/$1']);