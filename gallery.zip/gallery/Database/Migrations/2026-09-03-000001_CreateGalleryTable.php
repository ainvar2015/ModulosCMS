<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateGalleryTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'title'       => ['type' => 'VARCHAR', 'constraint' => 255],
            'slug'        => ['type' => 'VARCHAR', 'constraint' => 191],
            'description' => ['type' => 'TEXT', 'null' => true],
            'album'       => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'file_path'   => ['type' => 'VARCHAR', 'constraint' => 255],
            'sort_order'  => ['type' => 'INT', 'constraint' => 11, 'default' => 0],
            'active'      => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('album');
        $this->forge->addKey('active');
        $this->forge->createTable('gallery_images');
    }

    public function down()
    {
        $this->forge->dropTable('gallery_images');
    }
}