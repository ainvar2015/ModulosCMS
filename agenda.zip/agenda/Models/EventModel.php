<?php

namespace App\Modules\Agenda\Models;

use CodeIgniter\Model;

class EventModel extends Model
{
    protected $table         = 'agenda_events';
    protected $primaryKey    = 'id';
    protected $allowedFields = [
        'title', 'slug', 'summary', 'content', 'image_main',
        'location', 'start_at', 'end_at', 'external_url',
        'featured', 'active', 'meta_title', 'meta_desc',
    ];
    protected $useTimestamps = true;

    /** Próximos eventos: activos y con fecha de inicio futura, del más cercano al más lejano */
    public function getUpcoming(?int $limit = null): array
    {
        $builder = $this->where('active', 1)
            ->where('start_at >=', date('Y-m-d H:i:s'))
            ->orderBy('start_at', 'ASC');

        if ($limit) $builder->limit($limit);

        return $builder->findAll();
    }

    /** Eventos pasados, del más reciente al más antiguo */
    public function getPast(?int $limit = null): array
    {
        $builder = $this->where('active', 1)
            ->where('start_at <', date('Y-m-d H:i:s'))
            ->orderBy('start_at', 'DESC');

        if ($limit) $builder->limit($limit);

        return $builder->findAll();
    }

    public function getFeatured(int $limit = 1): array
    {
        return $this->where('active', 1)
            ->where('featured', 1)
            ->where('start_at >=', date('Y-m-d H:i:s'))
            ->orderBy('start_at', 'ASC')
            ->limit($limit)
            ->findAll();
    }

    public function getBySlug(string $slug): ?array
    {
        $row = $this->where('slug', $slug)->where('active', 1)->first();
        return $row ?: null;
    }
}
