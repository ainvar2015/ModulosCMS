<?php

use App\Modules\Agenda\Controllers\Admin\Events;

// Admin
$routes->group('admin/agenda', ['filter' => 'auth'], function ($routes) {
    $routes->get('events', [Events::class, 'index']);
    $routes->get('events/create', [Events::class, 'create']);
    $routes->post('events/store', [Events::class, 'store']);
    $routes->get('events/edit/(:num)', [Events::class, 'edit/$1']);
    $routes->post('events/update/(:num)', [Events::class, 'update/$1']);
    $routes->post('events/delete/(:num)', [Events::class, 'delete/$1']);
    $routes->get('events/toggle/(:num)', [Events::class, 'toggle/$1']);
    $routes->get('events/toggle-featured/(:num)', [Events::class, 'toggleFeatured/$1']);
});

// Front: la página-módulo es la ÚNICA entrada. Sub-rutas dinámicas vía
// $registerModuleSubRoutes en Config/Routes.php (rama 'agenda').
