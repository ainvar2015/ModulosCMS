<?php $this->extend('front/themes/' . ($themePath ?? 'default') . '/layout') ?>

<?php $this->section('content') ?>
<?php $pb = $pageBase ?? 'agenda'; ?>

<div class="container py-5">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url() ?>">Inicio</a></li>
            <li class="breadcrumb-item"><a href="<?= localized_url($pb) ?>">Agenda</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= esc($event['title']) ?></li>
        </ol>
    </nav>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="mb-2"><?= esc($event['title']) ?></h1>
            <p class="text-muted mb-4">
                <i class="bi bi-calendar-event"></i>
                <?= date('d/m/Y', strtotime($event['start_at'])) ?> · <?= date('H:i', strtotime($event['start_at'])) ?>h
                <?php if (!empty($event['end_at'])): ?>
                    — <?= date('d/m/Y', strtotime($event['end_at'])) ?> · <?= date('H:i', strtotime($event['end_at'])) ?>h
                <?php endif; ?>
                <?php if (!empty($event['location'])): ?>
                    <br><i class="bi bi-geo-alt"></i> <?= esc($event['location']) ?>
                <?php endif; ?>
            </p>

            <?php if (!empty($event['image_main'])): ?>
                <img src="<?= base_url($event['image_main']) ?>" class="img-fluid rounded shadow-sm mb-4 w-100" alt="<?= esc($event['title']) ?>">
            <?php endif; ?>

            <div class="content">
                <?= $event['content'] ?>
            </div>

            <?php if (!empty($event['external_url'])): ?>
                <a href="<?= esc($event['external_url']) ?>" target="_blank" rel="noopener" class="btn btn-primary mt-3">
                    <i class="bi bi-box-arrow-up-right"></i> Entradas / más información
                </a>
            <?php endif; ?>

            <a href="<?= localized_url($pb) ?>" class="btn btn-outline-primary mt-4">
                <i class="bi bi-arrow-left"></i> Volver a la agenda
            </a>
        </div>
    </div>

    <?php if (!empty($related)): ?>
        <hr class="my-5">
        <h2 class="h4 mb-4">Próximos eventos</h2>
        <div class="row g-4">
            <?php foreach ($related as $r): ?>
                <div class="col-md-4">
                    <div class="card h-100 shadow-sm">
                        <?php if (!empty($r['image_main'])): ?>
                            <img src="<?= thumb_url($r['image_main']) ?>" class="card-img-top" style="height:180px;object-fit:cover;" alt="<?= esc($r['title']) ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <small class="text-muted"><?= date('d/m/Y', strtotime($r['start_at'])) ?></small>
                            <h3 class="h6 mt-1"><?= esc($r['title']) ?></h3>
                            <a href="<?= localized_url($pb . '/evento/' . $r['slug']) ?>" class="btn btn-outline-primary btn-sm">Más información</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
<?php $this->endSection() ?>
