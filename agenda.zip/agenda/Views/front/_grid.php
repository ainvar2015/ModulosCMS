<?php
// Parcial: agenda de eventos. Sin layout (modo embed dentro de la página-módulo).
$pb = $pageBase ?? 'agenda';
$firstFeatured = !empty($featured) ? $featured[0] : null;

$fmtDate = static fn(string $dt) => date('d/m/Y', strtotime($dt));
$fmtTime = static fn(string $dt) => date('H:i', strtotime($dt));
?>

<?php if ($firstFeatured): ?>
    <?php $fe = $firstFeatured; ?>
    <div class="card mb-4 shadow-sm">
        <div class="row g-0">
            <div class="col-md-6">
                <?php if (!empty($fe['image_main'])): ?>
                    <img src="<?= thumb_url($fe['image_main']) ?>" class="img-fluid rounded-start w-100" style="height:100%;object-fit:cover;min-height:260px;" alt="<?= esc($fe['title']) ?>">
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <div class="card-body d-flex flex-column h-100">
                    <span class="badge bg-success align-self-start mb-2">Próximo evento destacado</span>
                    <h2 class="card-title h4"><?= esc($fe['title']) ?></h2>
                    <p class="card-text text-muted"><?= esc(mb_substr(strip_tags((string) $fe['summary']), 0, 220)) ?>…</p>
                    <div class="mt-auto">
                        <small class="text-muted d-block mb-2">
                            <i class="bi bi-calendar-event"></i> <?= $fmtDate($fe['start_at']) ?> · <?= $fmtTime($fe['start_at']) ?>h
                            <?php if (!empty($fe['location'])): ?>
                                · <i class="bi bi-geo-alt"></i> <?= esc($fe['location']) ?>
                            <?php endif; ?>
                        </small>
                        <a href="<?= localized_url($pb . '/evento/' . $fe['slug']) ?>" class="btn btn-primary">Más información</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if (empty($events)): ?>
    <div class="alert alert-info">No hay eventos próximos. Vuelve pronto.</div>
<?php else: ?>
    <div class="row g-4">
        <?php foreach ($events as $ev): if ($firstFeatured && $ev['id'] == $firstFeatured['id']) continue; ?>
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 shadow-sm">
                    <?php if (!empty($ev['image_main'])): ?>
                        <img src="<?= thumb_url($ev['image_main']) ?>" class="card-img-top" style="height:200px;object-fit:cover;" alt="<?= esc($ev['title']) ?>">
                    <?php endif; ?>
                    <div class="card-body d-flex flex-column">
                        <small class="text-muted mb-1">
                            <i class="bi bi-calendar-event"></i> <?= $fmtDate($ev['start_at']) ?> · <?= $fmtTime($ev['start_at']) ?>h
                            <?php if (!empty($ev['location'])): ?>
                                <br><i class="bi bi-geo-alt"></i> <?= esc($ev['location']) ?>
                            <?php endif; ?>
                        </small>
                        <h3 class="card-title h5"><?= esc($ev['title']) ?></h3>
                        <p class="card-text text-muted small"><?= esc(mb_substr(strip_tags((string) $ev['summary']), 0, 120)) ?>…</p>
                        <a href="<?= localized_url($pb . '/evento/' . $ev['slug']) ?>" class="btn btn-outline-primary btn-sm mt-auto align-self-start">
                            Más información
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
