<?php $this->extend('admin/layout') ?>

<?php $this->section('css') ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.20/dist/summernote-lite.min.css" rel="stylesheet">
<?php $this->endSection() ?>

<?php $this->section('content') ?>
<?php
$ev     = $e ?? null;
$isEdit = !empty($ev);
// DATETIME MySQL → formato datetime-local
$toLocal = static fn(?string $v) => $v ? date('Y-m-d\TH:i', strtotime($v)) : '';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2"><?= esc($title) ?></h1>
    <a href="<?= base_url('admin/agenda/events') ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Volver
    </a>
</div>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach (session()->getFlashdata('errors') as $err): ?><li><?= $err ?></li><?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?= $action ?>" method="post" id="eventForm">
    <?= csrf_field() ?>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Título <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" required
                            value="<?= old('title', $ev['title'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Slug</label>
                        <input type="text" name="slug" class="form-control"
                            value="<?= old('slug', $ev['slug'] ?? '') ?>">
                        <div class="form-text">Vacío = se genera del título.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Resumen</label>
                        <textarea name="summary" class="form-control" rows="3"><?= old('summary', $ev['summary'] ?? '') ?></textarea>
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Descripción</label>
                        <textarea name="content" id="content-default" class="form-control" rows="10"><?= old('content', $ev['content'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card shadow-sm mb-3">
                <div class="card-header bg-white fw-bold">Cuándo y dónde</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Inicio <span class="text-danger">*</span></label>
                        <input type="datetime-local" name="start_at" class="form-control" required
                            value="<?= old('start_at', $toLocal($ev['start_at'] ?? null)) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Fin</label>
                        <input type="datetime-local" name="end_at" class="form-control"
                            value="<?= old('end_at', $toLocal($ev['end_at'] ?? null)) ?>">
                        <div class="form-text">Opcional: para eventos de varios días o con hora de cierre.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Lugar</label>
                        <input type="text" name="location" class="form-control"
                            value="<?= old('location', $ev['location'] ?? '') ?>">
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold">Enlace externo</label>
                        <input type="url" name="external_url" class="form-control"
                            value="<?= old('external_url', $ev['external_url'] ?? '') ?>">
                        <div class="form-text">Entradas, programa, más info...</div>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Imagen destacada</label>
                        <div class="d-grid mb-2">
                            <button type="button" class="btn btn-outline-primary" id="pickImage">
                                <i class="bi bi-image"></i> Elegir de la biblioteca
                            </button>
                        </div>
                        <input type="hidden" name="image_main" id="imageMain" value="<?= old('image_main', $ev['image_main'] ?? '') ?>">
                        <div id="imagePreviewWrap" class="<?= empty($ev['image_main']) ? 'd-none' : '' ?>">
                            <img id="imagePreview" src="<?= !empty($ev['image_main']) ? thumb_url($ev['image_main']) : '' ?>" class="img-fluid rounded">
                        </div>
                    </div>
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" name="featured" value="1" id="feat"
                            <?= old('featured', $ev['featured'] ?? 0) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="feat">Destacado</label>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="active" value="1" id="act"
                            <?= old('active', $ev['active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="act">Activo</label>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Meta título (SEO)</label>
                        <input type="text" name="meta_title" class="form-control" value="<?= old('meta_title', $ev['meta_title'] ?? '') ?>">
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Meta descripción (SEO)</label>
                        <textarea name="meta_desc" class="form-control" rows="2"><?= old('meta_desc', $ev['meta_desc'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100">
                <i class="bi bi-check-lg"></i> <?= $isEdit ? 'Guardar cambios' : 'Crear evento' ?>
            </button>
        </div>
    </div>
</form>
<?php $this->endSection() ?>

<?php $this->section('js') ?>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.20/dist/summernote-lite.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.20/dist/lang/summernote-es-ES.min.js"></script>
<script>
    // Media Picker para la imagen destacada (mismo patrón que páginas/noticias)
    document.getElementById('pickImage').addEventListener('click', () => {
        MediaPicker.open((url, alt, meta) => {
            const rel = url.replace('<?= base_url() ?>', '');
            document.getElementById('imageMain').value = rel;
            const wrap = document.getElementById('imagePreviewWrap');
            wrap.classList.remove('d-none');
            document.getElementById('imagePreview').src = url;
        });
    });

    document.addEventListener('DOMContentLoaded', () => {
        // Botón personalizado del toolbar: biblioteca de medios
        const MediaButton = function(context) {
            const ui = $.summernote.ui;
            const button = ui.button({
                contents: '<i class="bi bi-images"></i>',
                tooltip: 'Biblioteca de medios',
                click: function() {
                    MediaPicker.open(function(url, alt) {
                        context.invoke('editor.insertImage', url, alt || '');
                    });
                },
            });
            return button.render();
        };

        const editorOpts = {
            height: 300,
            lang: 'es-ES',
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'italic', 'underline', 'clear']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['insert', ['link', 'media', 'picture']],
                ['view', ['fullscreen', 'codeview']]
            ],
            buttons: {
                media: MediaButton,
            },
            callbacks: {
                // Al intentar subir imagen desde el propio editor → biblioteca
                onImageUpload: function() {
                    const editor = $(this);
                    MediaPicker.open(function(url, alt) {
                        editor.summernote('insertImage', url, alt || '');
                    });
                },
            },
        };

        const el = document.getElementById('content-default');
        if (el) $(el).summernote(editorOpts);
    });
</script>
<?php $this->endSection() ?>
