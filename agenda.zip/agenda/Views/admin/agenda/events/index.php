<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Eventos</h1>
    <a href="<?= base_url('admin/agenda/events/create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Nuevo evento
    </a>
</div>

<form method="get" class="row g-2 mb-3">
    <div class="col-md-4">
        <input type="text" name="q" class="form-control" placeholder="Buscar por título, lugar o resumen..."
            value="<?= esc($q) ?>">
    </div>
    <div class="col-md-2">
        <button class="btn btn-outline-primary w-100"><i class="bi bi-search"></i> Filtrar</button>
    </div>
</form>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-3">Título</th>
                    <th>Fecha</th>
                    <th>Lugar</th>
                    <th>Destacado</th>
                    <th>Activo</th>
                    <th class="text-end pe-3">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($events)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">No hay eventos. Crea el primero.</td></tr>
                <?php else: foreach ($events as $e): ?>
                    <tr>
                        <td class="ps-3">
                            <strong><?= esc($e['title']) ?></strong><br>
                            <small class="text-muted"><code><?= esc($e['slug']) ?></code></small>
                        </td>
                        <td>
                            <?= date('d/m/Y H:i', strtotime($e['start_at'])) ?>
                            <?php if (!empty($e['end_at'])): ?>
                                <br><small class="text-muted">hasta <?= date('d/m/Y H:i', strtotime($e['end_at'])) ?></small>
                            <?php endif; ?>
                        </td>
                        <td><?= $e['location'] ? esc($e['location']) : '<span class="text-muted">—</span>' ?></td>
                        <td>
                            <a href="<?= base_url('admin/agenda/events/toggle-featured/' . $e['id']) ?>"
                               class="btn btn-sm <?= $e['featured'] ? 'btn-warning' : 'btn-outline-warning' ?>">
                                <i class="bi bi-star<?= $e['featured'] ? '-fill' : '' ?>"></i>
                            </a>
                        </td>
                        <td>
                            <a href="<?= base_url('admin/agenda/events/toggle/' . $e['id']) ?>"
                               class="btn btn-sm <?= $e['active'] ? 'btn-success' : 'btn-outline-secondary' ?>">
                                <?= $e['active'] ? 'Sí' : 'No' ?>
                            </a>
                        </td>
                        <td class="text-end pe-3">
                            <a href="<?= base_url('admin/agenda/events/edit/' . $e['id']) ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="<?= base_url('admin/agenda/events/delete/' . $e['id']) ?>" method="post" class="d-inline"
                                onsubmit="return confirm('¿Eliminar este evento?')">
                                <?= csrf_field() ?>
                                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $this->endSection() ?>
