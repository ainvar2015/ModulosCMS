<?php

return [
    'label'   => 'Agenda',
    'icon'    => 'bi-calendar-event',
    'segment' => 'agenda',
    'items'   => [
        ['url' => 'admin/agenda/events', 'label' => 'Eventos', 'icon' => 'bi-calendar2-week'],
    ],
];
