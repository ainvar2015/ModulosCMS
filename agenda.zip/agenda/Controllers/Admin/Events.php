<?php

namespace App\Modules\Agenda\Controllers\Admin;

use App\Controllers\Admin\BaseController;
use App\Modules\Agenda\Models\EventModel;

class Events extends BaseController
{
    protected $helpers = ['url', 'form', 'html', 'i18n', 'thumb'];

    protected function renderModule(string $view, array $data = [])
    {
        $base = isset($this->data) ? $this->data : [];
        return view('App\Modules\Agenda\Views\admin\\' . $view, array_merge($base, $data));
    }

    private function generateSlug(string $title): string
    {
        $slug = slugify($title);
        return $slug !== 'item' ? $slug : 'evento';
    }

    private function ensureUniqueSlug(string $slug, ?int $ignoreId = null): string
    {
        $model   = new EventModel();
        $base    = $slug;
        $counter = 1;
        while (true) {
            $builder = $model->where('slug', $slug);
            if ($ignoreId) $builder->where('id !=', $ignoreId);
            if (!$builder->first()) return $slug;
            $slug = $base . '-' . $counter++;
        }
    }

    public function index()
    {
        $model   = new EventModel();
        $request = service('request');

        $q       = trim((string) $request->getGet('q'));
        $builder = $model->orderBy('start_at', 'DESC');

        if ($q !== '') {
            $builder->groupStart()
                ->like('title', $q)
                ->orLike('location', $q)
                ->orLike('summary', $q)
                ->groupEnd();
        }

        return $this->renderModule('agenda/events/index', [
            'title'  => 'Eventos',
            'events' => $builder->findAll(),
            'q'      => $q,
        ]);
    }

    public function create()
    {
        return $this->renderModule('agenda/events/form', [
            'title'  => 'Nuevo evento',
            'e'      => null,
            'action' => base_url('admin/agenda/events/store'),
        ]);
    }

    public function edit($id)
    {
        $model = new EventModel();
        $event = $model->find($id);
        if (!$event) {
            return redirect()->to('/admin/agenda/events')->with('error', 'Evento no encontrado.');
        }

        return $this->renderModule('agenda/events/form', [
            'title'  => 'Editar evento',
            'e'      => $event,
            'action' => base_url('admin/agenda/events/update/' . $id),
        ]);
    }

    public function store()
    {
        return $this->save(null);
    }

    public function update($id)
    {
        return $this->save((int) $id);
    }

    private function save(?int $id)
    {
        $rules = [
            'title'    => 'required|min_length[2]|max_length[255]',
            'slug'     => 'permit_empty|max_length[255]',
            'start_at' => 'required',
        ];
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $model = new EventModel();

        $slug = trim((string) $this->request->getPost('slug'));
        if ($slug === '') {
            $slug = $this->generateSlug($this->request->getPost('title'));
        }
        $slug = $this->ensureUniqueSlug($slug, $id);

        // datetime-local ("2026-11-05T18:30") → DATETIME MySQL ("2026-11-05 18:30:00")
        $toMysql = static function (?string $v) {
            if (!$v) return null;
            $v = str_replace('T', ' ', $v);
            return strlen($v) === 16 ? $v . ':00' : $v;
        };

        $data = [
            'title'        => $this->request->getPost('title'),
            'slug'         => $slug,
            'summary'      => $this->request->getPost('summary'),
            'content'      => $this->request->getPost('content'),
            'image_main'   => $this->request->getPost('image_main') ?: null,
            'location'     => $this->request->getPost('location') ?: null,
            'start_at'     => $toMysql($this->request->getPost('start_at')),
            'end_at'       => $toMysql($this->request->getPost('end_at')),
            'external_url' => $this->request->getPost('external_url') ?: null,
            'featured'     => $this->request->getPost('featured') ? 1 : 0,
            'active'       => $this->request->getPost('active') ? 1 : 0,
            'meta_title'   => $this->request->getPost('meta_title') ?: null,
            'meta_desc'    => $this->request->getPost('meta_desc') ?: null,
        ];

        if ($id) {
            $model->update($id, $data);
        } else {
            $model->insert($data);
        }

        $msg = $id ? 'Evento actualizado.' : 'Evento creado.';
        return redirect()->to('/admin/agenda/events')->with('success', $msg);
    }

    public function toggle($id)
    {
        $model = new EventModel();
        $event = $model->find($id);
        if ($event) {
            $model->update($id, ['active' => $event['active'] ? 0 : 1]);
        }
        return redirect()->back();
    }

    public function toggleFeatured($id)
    {
        $model = new EventModel();
        $event = $model->find($id);
        if ($event) {
            $model->update($id, ['featured' => $event['featured'] ? 0 : 1]);
        }
        return redirect()->back();
    }

    public function delete($id)
    {
        $model = new EventModel();
        if (!$model->find($id)) {
            return redirect()->to('/admin/agenda/events')->with('error', 'Evento no encontrado.');
        }
        $model->delete($id);
        return redirect()->to('/admin/agenda/events')->with('success', 'Evento eliminado.');
    }
}
