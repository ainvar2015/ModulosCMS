<?php

return [
    'label'   => 'Idiomas',
    'icon'    => 'bi-globe',
    'segment' => 'languages',
    'items'   => [
        [
            'label' => 'Idiomas',
            'url'   => 'admin/languages',
            'icon'  => 'bi-translate',
        ],
    ],
];