<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Idiomas</h1>
    <a href="<?= base_url('admin/languages/create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Añadir idioma
    </a>
</div>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-3">Bandera</th>
                    <th>Código</th>
                    <th>Nombre</th>
                    <th>Por defecto</th>
                    <th>Activo</th>
                    <th class="text-end pe-3">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($languages as $l): ?>
                    <tr>
                        <td class="ps-3 fs-4"><?= $l['flag'] ?? '🏳️' ?></td>
                        <td><code><?= esc($l['code']) ?></code></td>
                        <td><?= esc($l['name']) ?></td>
                        <td>
                            <?php if ($l['is_default']): ?>
                                <span class="badge bg-primary"><i class="bi bi-check-circle"></i> Sí</span>
                            <?php else: ?>
                                <a href="<?= base_url('admin/languages/default/' . $l['id']) ?>" class="btn btn-sm btn-outline-secondary">Hacer default</a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-<?= $l['active'] ? 'success' : 'secondary' ?>">
                                <?= $l['active'] ? 'Sí' : 'No' ?>
                            </span>
                        </td>
                        <td class="text-end pe-3">
                            <a href="<?= base_url('admin/languages/edit/' . $l['id']) ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                            <?php if (!$l['is_default']): ?>
                                <a href="<?= base_url('admin/languages/delete/' . $l['id']) ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Eliminar?')"><i class="bi bi-trash"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $this->endSection() ?>