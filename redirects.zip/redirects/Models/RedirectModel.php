<?php

namespace App\Modules\Redirects\Models;

use CodeIgniter\Model;

class RedirectModel extends Model
{
    protected $table         = 'redirects';
    protected $primaryKey    = 'id';
    protected $allowedFields = ['from_path', 'to_path', 'code', 'hits', 'active'];
    protected $useTimestamps = true;

    /** Todas las redirecciones activas (para el filtro) */
    public function getActive(): array
    {
        return $this->where('active', 1)->findAll();
    }

    public function incrementHits(int $id): void
    {
        $this->db->table($this->table)
            ->set('hits', 'hits+1', false)
            ->where('id', $id)
            ->update();
    }
}