<?php

use App\Modules\Redirects\Controllers\Admin\Redirects;

// Admin únicamente: este módulo no tiene front
$routes->group('admin/redirects', ['filter' => 'auth'], function ($routes) {
    $routes->get('/', [Redirects::class, 'index']);
    $routes->get('create', [Redirects::class, 'create']);
    $routes->post('store', [Redirects::class, 'store']);
    $routes->get('edit/(:num)', [Redirects::class, 'edit/$1']);
    $routes->post('update/(:num)', [Redirects::class, 'update/$1']);
    $routes->post('delete/(:num)', [Redirects::class, 'delete/$1']);
    $routes->get('toggle/(:num)', [Redirects::class, 'toggle/$1']);
});