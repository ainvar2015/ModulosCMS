<?php $this->extend('admin/layout') ?>

<?php $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Redirecciones</h1>
    <a href="<?= base_url('admin/redirects/create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Nueva redirección
    </a>
</div>

<div class="nota-mia alert alert-info small">
    <i class="bi bi-info-circle"></i>
    Cuando cambies el slug de una página o la despubliques, crea aquí una redirección
    desde la URL antigua a la nueva para no perder posicionamiento ni romper enlaces externos.
</div>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-3">Desde</th>
                    <th>Hacia</th>
                    <th>Código</th>
                    <th>Usos</th>
                    <th>Activa</th>
                    <th class="text-end pe-3">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($redirects)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">No hay redirecciones creadas.</td></tr>
                <?php else: foreach ($redirects as $r): ?>
                    <tr>
                        <td class="ps-3"><code>/<?= esc($r['from_path']) ?></code></td>
                        <td><code><?= esc($r['to_path']) ?></code></td>
                        <td><span class="badge bg-<?= $r['code'] == 301 ? 'success' : 'warning' ?>"><?= $r['code'] ?></span></td>
                        <td><?= number_format($r['hits']) ?></td>
                        <td>
                            <a href="<?= base_url('admin/redirects/toggle/' . $r['id']) ?>"
                               class="btn btn-sm <?= $r['active'] ? 'btn-success' : 'btn-outline-secondary' ?>">
                                <?= $r['active'] ? 'Sí' : 'No' ?>
                            </a>
                        </td>
                        <td class="text-end pe-3">
                            <a href="<?= base_url('admin/redirects/edit/' . $r['id']) ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="<?= base_url('admin/redirects/delete/' . $r['id']) ?>" method="post" class="d-inline"
                                onsubmit="return confirm('¿Eliminar esta redirección?')">
                                <?= csrf_field() ?>
                                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $this->endSection() ?>