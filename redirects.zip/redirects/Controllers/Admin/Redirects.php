<?php

namespace App\Modules\Redirects\Controllers\Admin;

use App\Controllers\Admin\ModuleController;
use App\Modules\Redirects\Models\RedirectModel;

class Redirects extends ModuleController
{
    protected $helpers = ['url', 'form', 'html'];

    protected function moduleNamespace(): string
    {
        return 'App\Modules\Redirects';
    }

    public function index()
    {
        return $this->renderModule('redirects/index', [
            'title'     => 'Redirecciones',
            'redirects' => (new RedirectModel())->orderBy('from_path', 'ASC')->findAll(),
        ]);
    }

    public function create()
    {
        return $this->renderModule('redirects/form', [
            'title'  => 'Nueva redirección',
            'r'      => null,
            'action' => base_url('admin/redirects/store'),
        ]);
    }

    public function edit($id)
    {
        $row = (new RedirectModel())->find($id);
        if (!$row) {
            return redirect()->to('/admin/redirects')->with('error', 'Redirección no encontrada.');
        }
        return $this->renderModule('redirects/form', [
            'title'  => 'Editar redirección',
            'r'      => $row,
            'action' => base_url('admin/redirects/update/' . $id),
        ]);
    }

    public function store()
    {
        return $this->save(null);
    }

    public function update($id)
    {
        return $this->save((int) $id);
    }

    private function save(?int $id)
    {
        // Normalizamos: sin barra inicial, sin espacios
        $from = trim((string) $this->request->getPost('from_path'));
        $from = ltrim($from, '/');
        $to   = trim((string) $this->request->getPost('to_path'));

        $rules = [
            'from_path' => "required|regex_match[/^[^\\s]+$/]|max_length[500]" . ($id ? "|is_unique[redirects.from_path,id,{$id}]" : "|is_unique[redirects.from_path]"),
            'to_path'   => 'required|max_length[500]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Anti-bucle evidente
        if (strcasecmp(trim($from, '/'), trim($to, '/')) === 0 && !str_starts_with($to, 'http')) {
            return redirect()->back()->withInput()->with('error', 'El origen y el destino no pueden ser iguales.');
        }

        $model = new RedirectModel();
        $data  = [
            'from_path' => $from,
            'to_path'   => $to,
            'code'      => in_array($this->request->getPost('code'), ['301', '302'], true) ? (int) $this->request->getPost('code') : 301,
            'active'    => $this->request->getPost('active') ? 1 : 0,
        ];

        if ($id) {
            $model->update($id, $data);
        } else {
            $model->insert($data);
        }

        return redirect()->to('/admin/redirects')->with('success', 'Redirección guardada.');
    }

    public function toggle($id)
    {
        $model = new RedirectModel();
        $row   = $model->find($id);
        if ($row) {
            $model->update($id, ['active' => $row['active'] ? 0 : 1]);
        }
        return redirect()->back();
    }

    public function delete($id)
    {
        $model = new RedirectModel();
        if (!$model->find($id)) {
            return redirect()->to('/admin/redirects')->with('error', 'Redirección no encontrada.');
        }
        $model->delete($id);
        return redirect()->to('/admin/redirects')->with('success', 'Redirección eliminada.');
    }
}